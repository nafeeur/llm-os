#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
QEMU="${QEMU_X86_64:-qemu-system-x86_64}"
exec "$QEMU" -machine pc -m 128M -smp 1 \
  -drive format=raw,file="$ROOT/build/x86_64/llmos-x86_64.img" \
  -display none -serial stdio -monitor none -no-reboot
