#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
QEMU="${QEMU_AARCH64:-qemu-system-aarch64}"
exec "$QEMU" -machine virt -cpu cortex-a72 -m 256M -smp 1 \
  -kernel "$ROOT/build/aarch64-qemu/llmos-aarch64-qemu.bin" \
  -nographic -monitor none -no-reboot
