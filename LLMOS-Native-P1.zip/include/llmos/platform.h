#ifndef LLMOS_PLATFORM_H
#define LLMOS_PLATFORM_H

#include <stdint.h>
#include <stdbool.h>

void platform_early_init(uint64_t boot_arg);
void platform_putc(char c);
int platform_getc_nonblock(void);
uint64_t platform_cycles(void);
void platform_relax(void);
void platform_idle(void);
void platform_halt(void) __attribute__((noreturn));
const char *platform_name(void);
const char *platform_arch(void);
uint64_t platform_nominal_memory_bytes(void);

#endif
